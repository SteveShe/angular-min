'use strict';

var demoApp = angular.module('demoApp', ['ngRoute']);

demoApp.config(function ($routeProvider) {
    $routeProvider
        .when('/',
        {
            controller: 'SimpleController',
            templateUrl: 'view1.html'
        })
        .when('/view2',
        {
            controller: 'SimpleController',
            templateUrl: 'view2.html'
        })
        .otherwise({ redirectTo: '/' });
});


demoApp.controller('SimpleController', function ($scope) {
    $scope.family = [
        { name: 'Steve', city: 'Houston' }
    ];

    $scope.addFamilyMember = function () {
        $scope.family.push( { name: $scope.newFamilyMember.name, city: $scope.newFamilyMember.city } );
    }
});